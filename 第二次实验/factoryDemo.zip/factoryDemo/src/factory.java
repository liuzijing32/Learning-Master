public class factory {
    public Score getScore(String a){

        if(a==null){
            return null;
        }
        else if(a.equalsIgnoreCase("collegeA")){
            return new collegeA();
        }
        else if(a.equalsIgnoreCase("collegeB")){
            return new collegeB();
        }
        else if(a.equalsIgnoreCase("collegeC")){
            return new collegeC();
        }
        return null;
    }
}
