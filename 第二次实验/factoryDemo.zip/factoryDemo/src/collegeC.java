public class collegeC implements Score{
    public double calculate(int[] creditArray,int[] scoreArray){
        int sumCredit=0;
        int sumScore=0;
        for(int i=0;i<creditArray.length;i++){
            sumCredit+=creditArray[i];
            if(i==4){//英语课不计算在内
                sumCredit+=0;
            }
        }
        for(int t=0;t<scoreArray.length;t++){
            sumScore+=scoreArray[t]*creditArray[t];
            if(t==4){
                sumScore+=0;
            }
        }
        return sumScore/sumCredit;
    }
}
