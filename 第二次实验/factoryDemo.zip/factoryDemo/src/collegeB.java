public class collegeB implements Score{
    public double calculate(int[] creditArray,int[] scoreArray){
        int sumCredit=0;
        int sumScore=0;
        for(int i=0;i<creditArray.length;i++){
            sumCredit+=creditArray[i];
            if(i==1||i==2){//学院B不重视物理化学课
                sumCredit+=0.1*creditArray[i];
            }
        }
        for(int t=0;t<scoreArray.length;t++){
            sumScore+=scoreArray[t]*creditArray[t];
            if(t==1||t==2){//计算计算机课程时将学分翻倍
                sumScore+=scoreArray[t]*0.1*creditArray[t];
            }
        }
        return sumScore/sumCredit;
    }
}
