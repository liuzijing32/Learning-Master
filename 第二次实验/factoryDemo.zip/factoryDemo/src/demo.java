import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class demo {
    public static void main(String[] args) {
        int[] creditArray = new int[5];//用于存放学分的数组
        int[] scoreArray = new int[5];//用于存放成绩的数组
        int i1=0;//用来遍历数组的索引
        int i2=0;
        Connection con = null;
        //jdbc驱动
        String driver="com.mysql.cj.jdbc.Driver";
        String url="jdbc:mysql://localhost:3306/factoryDemo?serverTimezone=GMT%2B8";
        String user="root";
        String password="hhxxttxshhh123";
        try {
            //注册JDBC驱动程序
            Class.forName(driver);
            //建立连接
            con = DriverManager.getConnection(url, user, password);
            if (!con.isClosed()) {
                System.out.println("数据库连接成功");
            }

        } catch (ClassNotFoundException e) {
            System.out.println("数据库驱动没有安装");

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("数据库连接失败");
        }

        try {
            Statement stmt=con.createStatement();
            String sql="select id,name,credit,score from scores";
            ResultSet ret=stmt.executeQuery(sql);
            System.out.println("同一个学生的成绩，放在不同的学院综测成绩也不一样，学生成绩单为：");
            while(ret.next()){
                Integer id=ret.getInt("id");
                String name=ret.getString("name");
                Integer credit=ret.getInt("credit");
                Integer score=ret.getInt("score");
                creditArray[i1]=credit.intValue();
                scoreArray[i2]=score.intValue();
                i1++;i2++;

                System.out.print(id+" ");
                System.out.print(name+" ");
                System.out.print(credit+" ");
                System.out.println(score+" ");

            }
            con.close();//关闭连接
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            System.out.print("连接失败");
        }



        factory factory1=new factory();//创建工厂
        scoreDecorator score1=new goodScoreDecorator(factory1.getScore("collegeA"));//装饰器模式创建对象
        //Score score1=factory1.getScore("collegeA");//创建A学院对象
        double s1=score1.calculate(creditArray,scoreArray);
        System.out.println("A学院学生综测成绩为"+s1);
        //A学院计算计算机课程时将学分翻倍
        scoreDecorator score2=new goodScoreDecorator(factory1.getScore("collegeB"));//装饰器模式创建对象
       // Score score2=factory1.getScore("collegeB");//创建B学院对象
        double s2=score2.calculate(creditArray,scoreArray);
        System.out.println("B学院学生综测成绩为"+s2);
        //学院B不重视物理化学课
        scoreDecorator score3=new goodScoreDecorator(factory1.getScore("collegeC"));//装饰器模式创建对象
       // Score score3=factory1.getScore("collegeC");//创建C学院对象
        double s3=score3.calculate(creditArray,scoreArray);
        System.out.println("C学院学生综测成绩为"+s3);
        //C学院英语课不计算在内
    }
}
