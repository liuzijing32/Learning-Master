public class collegeA implements Score{
    public double calculate(int[] creditArray,int[] scoreArray){
        int sumCredit=0;
        int sumScore=0;
        for(int i=0;i<creditArray.length;i++){
            sumCredit+=creditArray[i];
            if(i==3){//计算计算机课程时将学分翻倍
                sumCredit+=2*creditArray[i];
            }
        }
        for(int t=0;t<scoreArray.length;t++){
            sumScore+=scoreArray[t]*creditArray[t];
            if(t==3){//计算计算机课程时将学分翻倍
                sumScore+=scoreArray[t]*2*creditArray[t];
            }
        }
        return sumScore/sumCredit;
    }
}
