public abstract class scoreDecorator implements Score{
    protected Score decoratedScore;
    public scoreDecorator(Score decoratedScore){
        this.decoratedScore=decoratedScore;
    }

    @Override
    public double calculate(int[] creditArray, int[] scoreArray) {
        return decoratedScore.calculate(creditArray,scoreArray);
    }

}
