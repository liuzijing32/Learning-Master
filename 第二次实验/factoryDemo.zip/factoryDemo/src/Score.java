public interface Score {
    double calculate(int[] creditArray,int[] scoreArray);
}
