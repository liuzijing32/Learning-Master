public class goodScoreDecorator extends scoreDecorator{
    public goodScoreDecorator(Score decoratedScore){
        super(decoratedScore);
    }

    @Override
    public double calculate(int[] creditArray, int[] scoreArray) {
        if(decoratedScore.calculate(creditArray, scoreArray)>=90){
        setGoodNew(decoratedScore);}else{
            setBadNew(decoratedScore);
        }
        return decoratedScore.calculate(creditArray,scoreArray);

    }
    private void setGoodNew(Score decoratedScore){
        System.out.println("成绩不错：");
    }
    private void setBadNew(Score decoratedScore){
        System.out.println("还需努力：");
    }
}
